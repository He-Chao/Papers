#!/bin/bash 
# Omitted from this zip file due to size. 49M compressed.
wget http://ai2-website.s3.amazonaws.com/data/test_submission_localize.zip
unzip test_submission_localize.zip
